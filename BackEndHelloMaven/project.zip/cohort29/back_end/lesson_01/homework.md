## Homework

### 1

- Проверить что установлена (или установить) утилиту curl.
    - Сделайте самостоятельно запросы приведенные в терии урока.

- В браузере открыть Menu -> More Tools -> Web Developer Tools -> вкладка Network.
    - В строку набрать адрес любого сайтa, походите по ссылкам, введите что-то в поиск
    - Какие status code и methods встретили?

- Из запросов найдите 2 хидера(headers, они же заголовки), найтие [информацию о них](https://developer.mozilla.org/ru/docs/Web/HTTP/Headers). Для чего они используются?*

- Прочитать про остальные [методы HTTP](https://developer.mozilla.org/ru/docs/Web/HTTP/Methods): GET, DELETE, PUT и другие

- Зарегистрируйтесь на https://www.postman.com/ и установите приложение postman
