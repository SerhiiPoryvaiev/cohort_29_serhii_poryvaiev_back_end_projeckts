## Задачи на урок:

1. Знакомство. О чем курс?
2. Что такое backend? Разница между frontend'ом и backend'ом
3. The open systems interconnection (OSI) model 
4. HTTP протокол
5. Утилита curl
