package repositories;

import model.User;

public interface UserCrudRepository extends CrudRepository<User>{
}
