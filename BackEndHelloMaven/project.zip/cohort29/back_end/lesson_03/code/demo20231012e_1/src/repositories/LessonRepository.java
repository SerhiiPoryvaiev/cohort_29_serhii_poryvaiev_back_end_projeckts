package repositories;

import model.Lesson;

public interface LessonRepository extends CrudRepository<Lesson> {
}
