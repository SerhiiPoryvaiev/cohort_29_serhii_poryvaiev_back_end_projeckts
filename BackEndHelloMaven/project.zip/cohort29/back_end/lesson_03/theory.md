

[Dependency Injection (DI) и Inversion of Control (IoC)](https://www.ait-tr.de/post/dependency-injection-di-%D0%B8-inversion-of-control-ioc)
