public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World");
        System.out.println("Hello Java");

        System.out.print("My name");
        System.out.print(" is");
        System.out.println(" Evgeny");
        System.out.println("Hello");
    }
    //Body  Тело класса
    //    gtzhjj
    //  переменная1
    //  переменная2

    // метод1
    // метод2
    /*
    gkjvkjvbojbolbolvovojvobobobobbpib
    jnjbjbkjbkjbkjbkjbkjbkbkbkb
     */



}
