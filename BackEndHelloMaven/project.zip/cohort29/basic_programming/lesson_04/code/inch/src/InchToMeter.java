import java.util.Scanner;

public class InchToMeter {
    public static void main(String[] args) {

    }
    // Написать программу, которая считывает с клавиатуры число в дюймах и конвертирует
    // его в метры. Один дюйм это 0,0254 метра
    // meter = inch * 0.0254
    // Вывести результат на экран
    Scanner scanner = new Scanner(System.in);
    
}
