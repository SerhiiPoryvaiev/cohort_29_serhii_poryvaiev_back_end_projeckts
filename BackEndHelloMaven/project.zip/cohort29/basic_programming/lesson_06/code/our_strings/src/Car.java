public class Car {
    String make;
    int year;
    String colour;

    public void drive(){
        System.out.println("I am driving");
    }

    public void stop(){
        System.out.println("I am stopping");
    }


}
