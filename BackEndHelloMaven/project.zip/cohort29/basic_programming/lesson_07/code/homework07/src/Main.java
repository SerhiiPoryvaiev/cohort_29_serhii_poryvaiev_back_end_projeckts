public class Main {

    public static void main(String[] args) {
        System.out.println(findDoubleLength("John"));


    }

    public static int findDoubleLength (String dog){

        int result =2* dog.length();

        return result;
      //  return 2* dog.length();
    }
}
