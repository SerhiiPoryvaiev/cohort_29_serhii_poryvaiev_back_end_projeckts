public class Main2 {
    public static void main(String[] args) {
        boolean A = true;
        boolean B = false;

        boolean C1 = A & B;
        boolean C2 = A | B;

        System.out.println("true & false = " + C1);
        System.out.println("true | false = " + C2);
    }
}
