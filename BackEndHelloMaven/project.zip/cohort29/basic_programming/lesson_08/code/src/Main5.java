public class Main5 {
    public static void main(String[] args) {
        // substring (0, pos)
        // substring (pos + 1, length)
    }
}
