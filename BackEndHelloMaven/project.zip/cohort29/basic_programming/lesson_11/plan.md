- Разбор домашнего задание
- Повторение методов indexOf, substring
- lastIndexOf()
- Character.isUpperCase, Character.isDigit, Character.isAlphabetic
- equalsIgnoreCase


