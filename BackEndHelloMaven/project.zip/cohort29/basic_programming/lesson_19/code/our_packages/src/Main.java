public class Main {

    public static void main(String[] args) {
      //  Calculator
      //  System.out.println(cal.add(1,2));
    }
}
