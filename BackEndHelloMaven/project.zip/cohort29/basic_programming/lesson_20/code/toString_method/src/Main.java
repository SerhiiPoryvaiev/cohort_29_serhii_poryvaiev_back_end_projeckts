public class Main {

    public static void main(String[] args) {
        Student s1 = new Student(1,"John","Berlin");

        // при печати обьекта вызывается метод toString
        System.out.println(s1);

        // метод toString в Джаве возвращает обьект в виде строки
    }
}
