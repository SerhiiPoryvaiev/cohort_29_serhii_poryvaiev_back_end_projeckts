public class JavaTeacher extends Teacher
{ // дочерний класс для класса Teacher

    String mainSubject = "Java";

}
