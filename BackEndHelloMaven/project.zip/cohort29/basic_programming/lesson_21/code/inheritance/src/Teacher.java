public class Teacher { // это родительский класс по отношению к классу JavaTeacher
    String profession = "Teacher";
    String schoolName = "AIT TR";

    public void teacherWorks(){ //  метод в классе Teacher
        System.out.println("Teacher is teaching"); //  выводит на экран надпись
    }
}
