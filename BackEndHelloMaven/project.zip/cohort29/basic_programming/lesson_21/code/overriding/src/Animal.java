public class Animal {

    public void sound(){
        System.out.println("Animal is making a sound");
    }
}
