public class Boy extends Human{

    @Override
    public void eat(){ // метод с тем же названием но другим содержанием в  дочернем классе
        System.out.println("Boy is eating");
    }
}
