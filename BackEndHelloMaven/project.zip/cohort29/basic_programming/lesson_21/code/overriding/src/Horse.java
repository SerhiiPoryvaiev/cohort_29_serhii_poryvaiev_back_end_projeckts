public class Horse extends Animal{

    public void sound(){
        System.out.println("Horse neighs");
    }

    public void run(){
        System.out.println("Horse  runs fast");
    }
}
