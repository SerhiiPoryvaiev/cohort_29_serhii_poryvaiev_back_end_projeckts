public class Human {

    public void eat(){ // определяем метод в родительском классе
        System.out.println("Human is eating");
    }
}
