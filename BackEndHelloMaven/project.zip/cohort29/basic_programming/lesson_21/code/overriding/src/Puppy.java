public class Puppy extends Dog{
    public void sound(){
        System.out.println("Puppy also barks");
    }
}
