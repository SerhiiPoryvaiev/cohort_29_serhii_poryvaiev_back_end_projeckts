/*package homework;

import cars.PassengerCar;

public class Main {
    public static void main(String[] args) {
        Cat cat1 = new Cat("Kathy",3,"red");
        Cat cat2 = new Cat("Mike",7,"black");

        System.out.println(cat1);
        System.out.println(cat2);

        Truck truck = new Truck();
        truck.drive();
        truck.stop();

        Car passengerCar = new PassengerCar();
        passengerCar.drive();
        passengerCar.stop();

    }
}*/
