/*import homework.Car;

public class PassengerCar extends Car {
    int numberOfSeats;

    @Override
    public void drive(){
        System.out.println("Passenger car is driving");
    }

    @Override
    public void stop(){
        System.out.println("Passenger car stops");
    }

}*/
