public class Lion extends Animal{

    public void sound(){
        System.out.println("Lion roars");
    }
}
