import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

class TestFindMaxMinDiff {

    @BeforeEach
    void setUp() {
    }


}