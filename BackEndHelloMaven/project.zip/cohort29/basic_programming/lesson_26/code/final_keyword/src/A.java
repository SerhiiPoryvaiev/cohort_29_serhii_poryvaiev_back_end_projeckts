//final class A {
public class A {
   final void method1(){
        System.out.println("This is a  final method");
    }
}
