public class B extends A{
  //  void method1(){
  //      System.out.println("Illegal");

  //  }
}
