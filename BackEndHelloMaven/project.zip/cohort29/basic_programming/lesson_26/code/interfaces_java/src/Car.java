public class Car implements Moveable,Driveable{

 public void canMove(){
     System.out.println("Car drives");
 }

 public void drive(){
     System.out.println("a car can drive");
 }
}
