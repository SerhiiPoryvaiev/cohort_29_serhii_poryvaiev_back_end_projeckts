public class Demo implements Interf2{
    @Override
    public void method2() {

    }

    @Override
    public void method1() {

    }
}
