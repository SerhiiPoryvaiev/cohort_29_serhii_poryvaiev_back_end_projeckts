public interface Flyable {
    void canFly();
}
