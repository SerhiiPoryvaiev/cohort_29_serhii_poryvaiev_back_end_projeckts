public interface Interf1 {
    void method1();
}
