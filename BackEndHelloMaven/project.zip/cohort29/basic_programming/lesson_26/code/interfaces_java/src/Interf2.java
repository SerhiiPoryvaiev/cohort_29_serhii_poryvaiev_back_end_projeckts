public interface Interf2 extends Interf1 {
    void method2();
}
