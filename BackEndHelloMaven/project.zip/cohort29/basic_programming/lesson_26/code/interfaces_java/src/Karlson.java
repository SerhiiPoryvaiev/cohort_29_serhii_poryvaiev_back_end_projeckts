public class Karlson implements Flyable{
    @Override
    public void canFly() {
        System.out.println("Karlson can fly");
    }
}
