public class Moscito implements Flyable{
    @Override
    public void canFly() {
        System.out.println("Moscito can fly");
    }
}
