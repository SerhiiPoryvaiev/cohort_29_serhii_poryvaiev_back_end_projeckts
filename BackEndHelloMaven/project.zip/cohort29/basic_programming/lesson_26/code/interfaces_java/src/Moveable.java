public interface Moveable {
 void canMove();
}
