public class Plane implements Flyable{

    @Override
    public void canFly() {
        System.out.println("A plane can fly");
    }
}
