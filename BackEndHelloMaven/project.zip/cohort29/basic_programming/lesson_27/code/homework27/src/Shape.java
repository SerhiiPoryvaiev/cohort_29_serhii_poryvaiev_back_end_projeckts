public interface Shape {

    double getPerimeter();
    double getArea();
}
