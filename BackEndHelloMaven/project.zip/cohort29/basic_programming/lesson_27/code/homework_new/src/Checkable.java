public interface Checkable {
    boolean check(String str);
}
