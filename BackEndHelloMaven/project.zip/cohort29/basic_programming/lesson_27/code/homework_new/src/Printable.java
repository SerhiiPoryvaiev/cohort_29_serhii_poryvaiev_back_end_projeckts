public interface Printable {
    void print(String s);
}
