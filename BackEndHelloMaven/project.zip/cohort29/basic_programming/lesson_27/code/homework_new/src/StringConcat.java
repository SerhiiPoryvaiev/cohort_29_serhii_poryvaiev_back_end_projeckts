public interface StringConcat {
    String concat( int a,int b);
}
