public interface Greetable {
    String sayHello (String name);
}
