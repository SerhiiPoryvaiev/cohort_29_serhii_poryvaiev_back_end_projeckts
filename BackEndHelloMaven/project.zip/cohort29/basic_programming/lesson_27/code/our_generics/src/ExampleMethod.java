public class ExampleMethod {

    static <T> void display( T elt){
        System.out.println("our element is "+  elt);
    }
}
