public interface Checkable {
    boolean check(String str); // принимает строку и что-то проверяет
}
