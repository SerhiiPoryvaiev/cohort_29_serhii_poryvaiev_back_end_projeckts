@FunctionalInterface
public interface Printable {
    void print(String s);
    //void print1(String s);
}
