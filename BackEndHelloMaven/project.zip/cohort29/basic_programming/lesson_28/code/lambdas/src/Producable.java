public interface Producable {
    String produce(); // ничего не принимает, а возвращает строку
}
