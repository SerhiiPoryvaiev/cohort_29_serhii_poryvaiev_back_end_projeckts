public interface StringConcat {
    String concat( int a,int b); // принимает два целых числа и возвращает строку
}
