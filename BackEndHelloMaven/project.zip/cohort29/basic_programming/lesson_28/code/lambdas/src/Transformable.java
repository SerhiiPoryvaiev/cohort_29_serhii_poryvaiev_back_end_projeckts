public interface Transformable {

  String  modify(String input); //  принимает строку и возвращает ее в измененном виде
}
