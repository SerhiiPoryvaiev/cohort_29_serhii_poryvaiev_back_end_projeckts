public class StateConstants {

    public static final double MIN_WAGE = 12.41;
}
