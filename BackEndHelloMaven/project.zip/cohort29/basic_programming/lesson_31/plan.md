# Задачи на урок:
1. Обсуждение и разбор дз
2. Методы Arrays.binarySearch, copyOf, copyOfRange
2. Практика, решение задач










