public enum Directions {
    EAST,
    WEST,
    NORTH,
    SOUTH
}
