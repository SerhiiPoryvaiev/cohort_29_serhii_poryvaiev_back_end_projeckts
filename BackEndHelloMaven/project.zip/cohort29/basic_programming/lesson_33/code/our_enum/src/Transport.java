public enum Transport {
    CAR,
    TRUCK,
    PLANE,
    TRAIN,
    BOAT

}
