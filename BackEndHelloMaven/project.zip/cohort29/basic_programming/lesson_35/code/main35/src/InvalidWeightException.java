public class InvalidWeightException extends Exception{

    public InvalidWeightException( String s){
        super(s);
    }
}
