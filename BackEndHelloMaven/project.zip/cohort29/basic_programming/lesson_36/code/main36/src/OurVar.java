public class OurVar {

    public static void main(String[] args) {
      //  int a = 1;

        // ключевое слово var  позволяет не задавать тип в явном виде при условии инициали
      //  зации переменной
        var a=1; // переменная типа var  должна быть обязательно инициализирована при создании
      //  a=2;
        int var = 25; //  в данном случае это просто название переменной
        var k =var;
        System.out.println(k);
        var c =3.0;
        var b = "str";


    }

}
