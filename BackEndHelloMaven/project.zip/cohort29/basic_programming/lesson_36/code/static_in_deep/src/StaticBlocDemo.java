public class StaticBlocDemo {
    public static String[] fruits = new String[3];

  // для инициализации переменных


    static  {
        fruits[0] = "Apple";
        fruits[1] = "Orange";
        fruits[2] = "Lemon";
    }
}
