public class OurVarClassExample {
  private int i;

    public OurVarClassExample(int i) {
        this.i = i;
    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }
}
