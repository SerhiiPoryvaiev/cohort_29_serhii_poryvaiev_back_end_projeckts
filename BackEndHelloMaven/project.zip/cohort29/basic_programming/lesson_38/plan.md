# Задачи на урок:
1. Collection Framework -List,ArrayList
2. Общее между ArrayList и обычными массивами  
3. Преимущества ArrayList  
4. Практика, решение задач





