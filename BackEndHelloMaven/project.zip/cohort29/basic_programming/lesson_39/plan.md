# Задачи на урок:

1. Разбор дз
2. Интерфейсы Iterator  и Iterable 
3. Напишем свой  ArrayList





