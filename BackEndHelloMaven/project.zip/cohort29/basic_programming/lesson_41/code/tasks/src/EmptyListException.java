public class EmptyListException extends Exception{
}
