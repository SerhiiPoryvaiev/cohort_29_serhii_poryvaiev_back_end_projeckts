см. код урока - tasks, класс Main
