***LinkedList***

Обобщенный класс LinkedList<E> представляет структуру данных в виде связанного списка. 

Вот некоторые из методов LinkedList:  

addFirst() / offerFirst(): добавляет элемент в начало списка

addLast() / offerLast(): добавляет элемент в конец списка

removeFirst() / pollFirst(): удаляет первый элемент из начала списка

removeLast() / pollLast(): удаляет последний элемент из конца списка

getFirst() / peekFirst(): получает первый элемент

getLast() / peekLast(): получает последний элемент

